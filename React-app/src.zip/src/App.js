import React from 'react';
import './index.css';
import Landing from './components/Landing';

const App = () => {
  return ( 
    <Landing />
  );
}

export default App;
